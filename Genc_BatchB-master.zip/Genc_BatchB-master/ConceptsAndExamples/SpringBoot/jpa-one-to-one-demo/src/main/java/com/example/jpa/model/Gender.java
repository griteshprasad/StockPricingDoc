package com.example.jpa.model;


public enum Gender {
    MALE,
    FEMALE
}
